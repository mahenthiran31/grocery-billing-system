# Restaurant POS & Billing Architecture

Shopkeeper/Cashier → React Restaurant POS → Express API → SQLite database.

Core flow:
1. Select table or takeaway.
2. Add menu items and quantities.
3. Create order.
4. Kitchen receives KOT and moves NEW → PREPARING → READY → SERVED.
5. Collect Cash/UPI/Card payment.
6. Mark order PAID and free the table.
7. Send digital notification through the messaging integration (demo/mock until a real provider is configured).
8. Reports read paid orders for sales analytics.
