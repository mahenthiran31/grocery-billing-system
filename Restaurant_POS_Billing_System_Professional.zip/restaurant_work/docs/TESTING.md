# Quick Test

1. Start backend and seed database.
2. Start frontend.
3. Login with 9876543210 / admin123.
4. Open Tables and confirm 12 demo tables.
5. Open Order / POS, select a table, add food and click Send Order to Kitchen.
6. Open Kitchen and move the order through statuses.
7. Return to POS and record Cash/UPI/Card payment.
8. Open Bills and Reports.
9. Messaging buttons are demo-only; connect an approved SMS/WhatsApp provider before production use.
