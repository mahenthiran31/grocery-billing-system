# Restaurant POS & Billing System

A professional restaurant food ordering, kitchen, table and billing system.

## Included
- Restaurant dashboard
- Table management with visual table status
- Menu management: add, edit, price, stock, availability, remove/restore
- Food images with built-in professional menu artwork
- Upload custom JPG/PNG/WebP food images; images are resized in-browser
- POS with image-based food cards
- Kitchen Order Ticket workflow
- Bills and payments: Cash / UPI / Card
- Reports
- SMS / WhatsApp provider hooks (mock until real provider credentials are configured)
- SQLite database

## Demo login
Mobile: `9876543210`
Password: `admin123`

## Run
### Backend
```powershell
cd backend
npm.cmd install
npm.cmd run seed
npm.cmd run dev
```

### Frontend (new terminal)
```powershell
cd frontend
npm.cmd install
npm.cmd run dev
```

Open `http://localhost:5173`.

## Food images
Default food images are stored in `frontend/public/food/`. In Menu Management, use **Food image** to upload a custom JPG/PNG/WebP image. The UI automatically resizes the image for the local project and shows it in the Menu and POS screens.

For a production deployment, move uploaded images to object storage/CDN rather than storing base64 image data in SQLite.
